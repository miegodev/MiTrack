//
//  MiTrack.h
//  MiTrack
//
//  Created by Jasper Siebelink on 2017/07/08.
//  Copyright © 2017 Jasper Siebelink. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for MiTrack.
FOUNDATION_EXPORT double MiTrackVersionNumber;

//! Project version string for MiTrack.
FOUNDATION_EXPORT const unsigned char MiTrackVersionString[];
